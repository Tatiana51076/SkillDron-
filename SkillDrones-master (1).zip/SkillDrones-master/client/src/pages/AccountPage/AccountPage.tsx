import React from "react";

const AccountPage: React.FC = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Здесь будут данные и настройки аккаунта</h2>
    </div>
  );
};

export default AccountPage;
