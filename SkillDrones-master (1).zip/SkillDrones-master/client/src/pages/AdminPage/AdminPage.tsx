import React from "react";

const AdminPage: React.FC = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Здесь будут инструменты админа</h2>
    </div>
  );
};

export default AdminPage;
