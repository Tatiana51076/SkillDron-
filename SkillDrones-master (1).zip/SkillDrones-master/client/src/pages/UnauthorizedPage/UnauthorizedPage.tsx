import React from "react";

const UnauthorizedPage: React.FC = () => {
  return <div style={{ padding: "20px" }}></div>;
};

export default UnauthorizedPage;
