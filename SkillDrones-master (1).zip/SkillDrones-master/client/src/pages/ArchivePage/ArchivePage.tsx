import React from "react";

const ArchivePage: React.FC = () => {
  return (
    <div style={{ padding: "20px" }}>
      {" "}
      <h2>Здесь будут архивные отчеты</h2>{" "}
    </div>
  );
};

export default ArchivePage;
