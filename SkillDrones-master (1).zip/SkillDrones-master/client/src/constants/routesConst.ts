export const ROUTES = {
  MAIN: '/',
  LOGIN: '/login',
  UNAUTH: '/unauthorized',
  ACCOUNT: '/account',
  ANALYTICS: '/analytics',
  ARCHIVE: '/archive',
  UPLOAD: '/upload',
  ADMIN: '/admin',
};