declare module 'swiper/css' {
  const styles: never;
  export default styles;
}

declare module 'swiper/css/free-mode' {
  const styles: never;
  export default styles;
}